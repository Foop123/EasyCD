-- EasyCD data: settings defaults, tracked defensives, crowd-control list
local ADDON_NAME, ns = ...

ns.IS_FOREVER = (select(4, GetBuildInfo()) or 0) >= 16000
ns.issecret = issecretvalue or function() return false end

ns.GetSpellInfoCompat = GetSpellInfo or function(id)
    if C_Spell and C_Spell.GetSpellInfo then
        local i = C_Spell.GetSpellInfo(id)
        if i then return i.name, nil, i.iconID end
    end
end

----------------------------------------------------------------------
-- Settings
----------------------------------------------------------------------
ns.DEFAULTS = {
    enabled = true,
    -- enemy defensive icons on nameplates
    size = 40, max = 5, gap = 3, x = 0, y = 14,
    anchor = "ABOVE",            -- ABOVE / BELOW the nameplate
    align = "CENTER",            -- CENTER / LEFT / RIGHT
    alpha = 1, textScale = 1,
    showText = true, showSwipe = true, showBorder = true, pulse = true,
    onlyTarget = false, friendly = false,
    -- enemy offensive CC cooldown tracker (Blind, Scatter Shot ...)
    ccd = true, ccdMin = 30, ccdSize = 32, ccdMax = 4, ccdY = 60, ccdOnlyTarget = false,
    ccdDisabled = {},            -- ccdDisabled[english spell name] = true
    disabled = {},               -- disabled[english spell name] = true
    -- crowd control alert
    cc = true, ccSize = 72, ccX = 0, ccY = 80, ccMax = 3,
    ccText = true, ccName = true, ccSound = false,
    ccCats = { stun = true, fear = true, incap = true, root = true, silence = true, disarm = true },
    -- minimap button
    hideMinimap = false, minimapAngle = 200,
}

local function fill(dst, src)
    for k, v in pairs(src) do
        if dst[k] == nil then
            if type(v) == "table" then dst[k] = {}; fill(dst[k], v) else dst[k] = v end
        elseif type(v) == "table" and type(dst[k]) == "table" then
            fill(dst[k], v)
        end
    end
end

-- Called from hot paths, so the defaults are only merged once per saved table.
local cachedDB
function ns.DB()
    local db = EDTDB
    if db and db == cachedDB then return db end
    db = db or {}
    EDTDB = db
    fill(db, ns.DEFAULTS)
    cachedDB = db
    return db
end

----------------------------------------------------------------------
-- Enemy defensives (Vanilla): { english name, fallback duration, {spell ids} }
-- Matching is by name AND id, so every rank is covered. Add your own lines!
----------------------------------------------------------------------
ns.SPELLS = {
    -- Mage
    { "Ice Block",              10,  { 11958 } },
    { "Ice Barrier",            60,  { 11426, 13031, 13032, 13033 } },
    { "Frost Ward",             30,  { 6143, 8461, 8462, 10177, 28609 } },
    { "Fire Ward",              30,  { 543, 8457, 8458, 10223, 10225 } },
    { "Mana Shield",            60,  { 1463, 8494, 8495, 10191, 10192, 10193 } },
    -- Warrior
    { "Shield Wall",            10,  { 871 } },
    { "Last Stand",             20,  { 12975 } },
    { "Shield Block",           5,   { 2565 } },
    { "Berserker Rage",         10,  { 18499 } },
    -- Paladin
    { "Divine Shield",          12,  { 642, 1020 } },
    { "Divine Protection",      8,   { 498, 5573 } },
    { "Blessing of Protection", 10,  { 1022, 5599, 10278 } },
    { "Blessing of Freedom",    16,  { 1044 } },
    { "Blessing of Sacrifice",  30,  { 6940, 20729 } },
    -- Priest
    { "Power Word: Shield",     30,  { 17, 592, 600, 3747, 6065, 6066, 10898, 10899, 10900, 10901 } },
    { "Fear Ward",              180, { 6346 } },
    { "Spirit of Redemption",   15,  { 27827 } },
    -- Rogue
    { "Evasion",                15,  { 5277, 26669 } },
    { "Vanish",                 10,  { 11327, 11329 } },
    -- Druid
    { "Barkskin",               15,  { 22812 } },
    { "Frenzied Regeneration",  10,  { 22842, 22895, 22896 } },
    -- Hunter
    { "Deterrence",             10,  { 19263 } },
    -- Warlock
    { "Shadow Ward",            30,  { 6229, 11739, 11740, 28610 } },
    { "Sacrifice",              30,  { 7812, 19438, 19440, 19441, 19442, 19443 } },
    -- Racial
    { "Stoneform",              8,   { 20594 } },
    -- Consumables
    { "Free Action",            30,  { 6615 } },
    { "Living Free Action",     5,   { 24364 } },
    { "Limited Invulnerability",6,   { 3169 } },
    { "Swiftness",              15,  { 2379 } },
    { "Greater Stoneshield",    120, { 17540 } },
    { "Fire Protection",        60,  { 7233, 17543 } },
    { "Frost Protection",       60,  { 7239, 17544 } },
    { "Holy Protection",        60,  { 7245, 17545 } },
    { "Nature Protection",      60,  { 7254, 17546 } },
    { "Shadow Protection",      60,  { 7242, 17548 } },
    { "Arcane Protection",      60,  { 17549 } },
}

----------------------------------------------------------------------
-- Crowd control that lands on YOU: { english name, category, {spell ids} }
-- Categories: stun, fear, incap (polymorph/sap/sleep/charm...), root, silence, disarm
----------------------------------------------------------------------
ns.CC_CATS = {
    stun    = { label = "Stuns",                     r = 1.00, g = 0.25, b = 0.25 },
    fear    = { label = "Fears",                     r = 0.70, g = 0.40, b = 1.00 },
    incap   = { label = "Polymorph / Sap / Sleep / Charm", r = 1.00, g = 0.80, b = 0.20 },
    root    = { label = "Roots",                     r = 0.30, g = 0.90, b = 0.30 },
    silence = { label = "Silences / Interrupts",     r = 0.30, g = 0.70, b = 1.00 },
    disarm  = { label = "Disarms",                   r = 1.00, g = 0.55, b = 0.15 },
}
ns.CC_ORDER = { "stun", "fear", "incap", "root", "silence", "disarm" }

ns.CC = {
    -- stuns
    { "Cheap Shot", "stun", { 1833 } },
    { "Kidney Shot", "stun", { 408, 8643 } },
    { "Hammer of Justice", "stun", { 853, 5588, 5589, 10308 } },
    { "Bash", "stun", { 5211, 6798, 8983 } },
    { "Pounce", "stun", { 9005, 9823, 9827 } },
    { "Charge Stun", "stun", { 7922 } },
    { "Intercept Stun", "stun", { 20253, 20614, 20615 } },
    { "Concussion Blow", "stun", { 12809 } },
    { "Mace Stun Effect", "stun", { 5530 } },
    { "Intimidation", "stun", { 24394 } },
    { "War Stomp", "stun", { 20549 } },
    { "Revenge Stun", "stun", { 12798 } },
    { "Impact", "stun", { 12355 } },
    { "Starfire Stun", "stun", { 16922 } },
    { "Stun", "stun", { 56, 20170 } },
    -- fears / horrors
    { "Fear", "fear", { 5782, 6213, 6215 } },
    { "Howl of Terror", "fear", { 5484, 17928 } },
    { "Psychic Scream", "fear", { 8122, 8124, 10888, 10890 } },
    { "Intimidating Shout", "fear", { 5246 } },
    { "Death Coil", "fear", { 6789, 17925, 17926 } },
    { "Scare Beast", "fear", { 1513, 14326, 14327 } },
    -- incapacitates, sleeps, charms
    { "Polymorph", "incap", { 118, 12824, 12825, 12826 } },
    { "Polymorph: Pig", "incap", { 28272 } },
    { "Polymorph: Turtle", "incap", { 28271 } },
    { "Sap", "incap", { 6770, 2070, 11297 } },
    { "Gouge", "incap", { 1776 } },
    { "Blind", "incap", { 2094 } },
    { "Hibernate", "incap", { 2637, 18657, 18658 } },
    { "Wyvern Sting", "incap", { 19386, 24132, 24133 } },
    { "Freezing Trap Effect", "incap", { 3355, 14308, 14309 } },
    { "Repentance", "incap", { 20066 } },
    { "Shackle Undead", "incap", { 9484, 9485, 10955 } },
    { "Mind Control", "incap", { 605, 10911, 10912 } },
    { "Seduction", "incap", { 6358 } },
    { "Enslave Demon", "incap", { 1098, 11725, 11726 } },
    { "Sleep", "incap", { 700, 1090, 2937 } },
    -- roots
    { "Entangling Roots", "root", { 339, 1062, 5195, 5196, 9852, 9853 } },
    { "Frost Nova", "root", { 122, 865, 6131, 10230 } },
    { "Frostbite", "root", { 12497 } },
    { "Improved Hamstring", "root", { 23694 } },
    { "Counterattack", "root", { 19306, 20909, 20910 } },
    { "Entrapment", "root", { 19185 } },
    -- silences / interrupts
    { "Counterspell - Silenced", "silence", { 18469 } },
    { "Silence", "silence", { 15487 } },
    { "Kick - Silenced", "silence", { 18425 } },
    { "Garrote - Silence", "silence", { 1330 } },
    { "Spell Lock", "silence", { 19244, 19647 } },
    { "Shield Bash - Silenced", "silence", { 18498 } },
    -- disarms
    { "Disarm", "disarm", { 676 } },
    { "Riposte", "disarm", { 14251 } },
}

-- Forever / Mainline Loss of Control types -> category (catches CC not listed above)
ns.LOC_CAT = {
    STUN = "stun", STUN_MECHANIC = "stun",
    FEAR = "fear", FEAR_MECHANIC = "fear",
    CONFUSE = "incap", CHARM = "incap", POSSESS = "incap",
    ROOT = "root",
    SILENCE = "silence", PACIFYSILENCE = "silence", SCHOOL_INTERRUPT = "silence", INTERRUPT = "silence",
    DISARM = "disarm", PACIFY = "disarm",
}

----------------------------------------------------------------------
-- Enemy OFFENSIVE crowd control with a real cooldown: { english name, cooldown (sec), {spell ids} }
-- The timer starts when the enemy uses the ability and counts down until it is
-- available again. Cooldowns are the Vanilla values; talents/Forever changes may
-- differ, so edit the numbers here if needed. Only abilities with a cooldown of at
-- least "ccdMin" seconds are shown (change that in the settings).
----------------------------------------------------------------------
ns.CC_CDS = {
    -- Rogue
    { "Blind",               300, { 2094 } },
    { "Kidney Shot",         20,  { 408, 8643 } },
    { "Gouge",               10,  { 1776 } },
    -- Hunter
    { "Scatter Shot",        30,  { 19503 } },
    { "Freezing Trap",       15,  { 1499, 14310, 14311 } },
    { "Wyvern Sting",        120, { 19386, 24132, 24133 } },
    { "Intimidation",        60,  { 19577 } },
    -- Mage
    { "Counterspell",        30,  { 2139 } },
    { "Frost Nova",          25,  { 122, 865, 6131, 10230 } },
    -- Warlock
    { "Death Coil",          120, { 6789, 17925, 17926 } },
    { "Howl of Terror",      40,  { 5484, 17928 } },
    { "Spell Lock",          24,  { 19244, 19647 } },
    -- Priest
    { "Psychic Scream",      30,  { 8122, 8124, 10888, 10890 } },
    { "Silence",             45,  { 15487 } },
    -- Warrior
    { "Intimidating Shout",  180, { 5246 } },
    { "Concussion Blow",     45,  { 12809 } },
    { "Intercept",           30,  { 20252, 20616, 20617 } },
    -- Paladin
    { "Hammer of Justice",   60,  { 853, 5588, 5589, 10308 } },
    { "Repentance",          60,  { 20066 } },
    -- Druid
    { "Bash",                60,  { 5211, 6798, 8983 } },
    -- Racial
    { "War Stomp",           120, { 20549 } },
}
