-- EasyCD settings window, minimap button, AddOns options entry and slash commands
local ADDON_NAME, ns = ...
local DB, IS_FOREVER = ns.DB, ns.IS_FOREVER

local cfg, minimapBtn
local refreshers = {}

local function say(msg) print("|cff33ff99EasyCD:|r " .. msg) end

local function changed()
    ns.RefreshAll()
    ns.CCRefresh()
end

local function refreshWidgets()
    for _, r in ipairs(refreshers) do r() end
end

local function tooltip(owner, text)
    GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
    GameTooltip:SetText(text, 1, 1, 1, 1, true)
    GameTooltip:Show()
end

--------------------------------------------------------------------------
-- widgets
--------------------------------------------------------------------------
local function makeCheck(parent, label, x, y, get, set, tip, width)
    local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    cb:SetSize(24, 24)
    cb:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    local t = cb.Text or cb.text
    if not t then
        t = cb:CreateFontString(nil, "OVERLAY")
        t:SetPoint("LEFT", cb, "RIGHT", 2, 0)
    end
    t:SetFontObject("GameFontHighlightSmall")
    t:SetText(label)
    t:SetWidth(width or 150)
    t:SetJustifyH("LEFT")
    t:SetWordWrap(false)
    cb:SetScript("OnClick", function(self)
        set(self:GetChecked() and true or false)
        changed()
    end)
    if tip then
        cb:SetScript("OnEnter", function(self) tooltip(self, tip) end)
        cb:SetScript("OnLeave", function() GameTooltip:Hide() end)
    end
    cb:SetChecked(get() and true or false)
    refreshers[#refreshers + 1] = function() cb:SetChecked(get() and true or false) end
    return cb
end

local function makeButton(parent, text, x, y, w, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(w, 22)
    b:SetPoint("TOPLEFT", parent, "TOPLEFT", x, y)
    b:SetText(text)
    b:SetScript("OnClick", onClick)
    return b
end

local function makeStepper(parent, label, x, y, get, set, step, minv, maxv, fmt)
    fmt = fmt or "%d"
    local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    fs:SetPoint("TOPLEFT", x, y - 5)
    fs:SetText(label)
    local val = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    val:SetPoint("TOPLEFT", x + 196, y - 5)
    val:SetWidth(44)
    val:SetJustifyH("CENTER")
    local function show() val:SetText(string.format(fmt, get())) end
    local function bump(d)
        local v = get() + d * step
        v = math.floor(v / step + 0.5) * step              -- kill float drift
        set(math.max(minv, math.min(maxv, v)))
        show()
        changed()
    end
    makeButton(parent, "-", x + 160, y, 28, function() bump(-1) end)
    makeButton(parent, "+", x + 248, y, 28, function() bump(1) end)
    refreshers[#refreshers + 1] = show
    show()
end

-- button that cycles through values
local function makeCycle(parent, label, x, y, get, set, values, names)
    local fs = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    fs:SetPoint("TOPLEFT", x, y - 5)
    fs:SetText(label)
    local b = makeButton(parent, "", x + 160, y, 116, nil)
    local function show()
        local v = get()
        for i, val in ipairs(values) do
            if val == v then b:SetText(names and names[i] or val); return end
        end
        b:SetText(tostring(v))
    end
    b:SetScript("OnClick", function()
        local idx = 1
        for i, val in ipairs(values) do if val == get() then idx = i end end
        set(values[idx % #values + 1])
        show()
        changed()
    end)
    refreshers[#refreshers + 1] = show
    show()
end

--------------------------------------------------------------------------
-- settings window
--------------------------------------------------------------------------
local function build()
    local f = CreateFrame("Frame", "EasyCDConfig", UIParent, "BackdropTemplate")
    f:SetSize(430, 620)
    f:SetPoint("CENTER")
    f:SetFrameStrata("DIALOG")
    f:SetMovable(true)
    f:EnableMouse(true)
    f:SetClampedToScreen(true)
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8x8", edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
    f:SetBackdropColor(0.07, 0.07, 0.09, 0.96)
    f:SetBackdropBorderColor(0.4, 0.35, 0.15, 1)
    tinsert(UISpecialFrames, "EasyCDConfig")

    local title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 14, -12)
    title:SetText("EasyCD")
    local sub = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    sub:SetPoint("LEFT", title, "RIGHT", 8, -2)
    sub:SetText((IS_FOREVER and "Forever" or "Classic Era") .. "  -  drag to move, wheel to scroll")

    local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -2, -2)

    -- scroll area (same approach as EasyBuff)
    local sf = CreateFrame("ScrollFrame", nil, f)
    sf:SetPoint("TOPLEFT", 12, -40)
    sf:SetPoint("BOTTOMRIGHT", -26, 12)
    local child = CreateFrame("Frame", nil, sf)
    child:SetSize(392, 10)
    sf:SetScrollChild(child)
    sf:EnableMouseWheel(true)

    local bar = CreateFrame("Slider", nil, f)
    bar:SetOrientation("VERTICAL")
    bar:SetPoint("TOPRIGHT", -10, -40)
    bar:SetPoint("BOTTOMRIGHT", -10, 12)
    bar:SetWidth(8)
    local track = bar:CreateTexture(nil, "BACKGROUND")
    track:SetAllPoints()
    track:SetColorTexture(1, 1, 1, 0.08)
    bar:SetThumbTexture("Interface\\Buttons\\WHITE8x8")
    local thumb = bar:GetThumbTexture()
    thumb:SetSize(8, 40)
    thumb:SetVertexColor(0.85, 0.7, 0.2, 0.9)
    bar:SetMinMaxValues(0, 1)
    bar:SetValue(0)
    bar:SetScript("OnValueChanged", function(_, v) sf:SetVerticalScroll(v) end)

    local function updateScroll()
        local max = math.max(0, child:GetHeight() - sf:GetHeight())
        bar:SetMinMaxValues(0, max)
        bar:SetShown(max > 0)
        if sf:GetVerticalScroll() > max then sf:SetVerticalScroll(max); bar:SetValue(max) end
    end
    sf:SetScript("OnMouseWheel", function(self, delta)
        local _, max = bar:GetMinMaxValues()
        local v = math.max(0, math.min(max, self:GetVerticalScroll() - delta * 48))
        self:SetVerticalScroll(v)
        bar:SetValue(v)
    end)
    f:SetScript("OnShow", updateScroll)

    ------------------------------------------------------------------
    -- content (simple top-to-bottom layout)
    ------------------------------------------------------------------
    local y, col = -4, 0

    local function endChecks()
        if col == 1 then col = 0; y = y - 26 end
    end
    local function header(text)
        endChecks()
        y = y - 8
        local h = child:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        h:SetPoint("TOPLEFT", 4, y)
        h:SetText(text)
        local line = child:CreateTexture(nil, "ARTWORK")
        line:SetPoint("TOPLEFT", 4, y - 16)
        line:SetSize(370, 1)
        line:SetColorTexture(0.4, 0.35, 0.15, 0.8)
        y = y - 24
    end
    local function note(text)
        endChecks()
        local n = child:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        n:SetPoint("TOPLEFT", 4, y)
        n:SetWidth(370)
        n:SetJustifyH("LEFT")
        n:SetText(text)
        y = y - (n:GetStringHeight() + 6)
    end
    local function check(label, get, set, tip)
        makeCheck(child, label, col == 0 and 4 or 200, y, get, set, tip, 150)
        if col == 0 then col = 1 else col = 0; y = y - 26 end
    end
    local function stepper(label, get, set, step, minv, maxv, fmt)
        endChecks()
        makeStepper(child, label, 4, y, get, set, step, minv, maxv, fmt)
        y = y - 30
    end
    local function cycle(label, get, set, values, names)
        endChecks()
        makeCycle(child, label, 4, y, get, set, values, names)
        y = y - 30
    end
    local function buttons(list)
        endChecks()
        local x, made = 4, {}
        for _, b in ipairs(list) do
            made[#made + 1] = makeButton(child, b[1], x, y, b[2], b[3])
            x = x + b[2] + 8
        end
        y = y - 30
        return made
    end

    ---- General ------------------------------------------------------
    header("General")
    check("Addon enabled", function() return DB().enabled end, function(v) DB().enabled = v end,
        "Turn everything (nameplate icons and the CC alert) on or off.")
    check("Hide minimap button", function() return DB().hideMinimap end,
        function(v) DB().hideMinimap = v; if minimapBtn then minimapBtn:SetShown(not v) end end,
        "You can still open this window with /edt")

    ---- Nameplate icons ---------------------------------------------
    header("Enemy defensive icons on nameplates")
    stepper("Icon size", function() return DB().size end, function(v) DB().size = v end, 4, 16, 128)
    stepper("Max icons per nameplate", function() return DB().max end, function(v) DB().max = v end, 1, 1, 10)
    stepper("Spacing between icons", function() return DB().gap end, function(v) DB().gap = v end, 1, 0, 24)
    stepper("Height from nameplate", function() return DB().y end, function(v) DB().y = v end, 2, -60, 120)
    stepper("Horizontal offset", function() return DB().x end, function(v) DB().x = v end, 2, -120, 120)
    stepper("Opacity", function() return DB().alpha end, function(v) DB().alpha = v end, 0.1, 0.2, 1, "%.1f")
    stepper("Number size", function() return DB().textScale end, function(v) DB().textScale = v end, 0.1, 0.5, 2.5, "%.1f")
    cycle("Position", function() return DB().anchor end, function(v) DB().anchor = v end,
        { "ABOVE", "BELOW" }, { "Above nameplate", "Below nameplate" })
    cycle("Alignment", function() return DB().align end, function(v) DB().align = v end,
        { "CENTER", "LEFT", "RIGHT" }, { "Centered", "Left", "Right" })
    check("Show countdown numbers", function() return DB().showText end, function(v) DB().showText = v end,
        "Seconds left on each icon.")
    check("Show clock swipe", function() return DB().showSwipe end, function(v) DB().showSwipe = v end,
        "The dark sweep that shrinks as the timer runs down.")
    check("Show icon border", function() return DB().showBorder end, function(v) DB().showBorder = v end)
    check("Pulse when about to end", function() return DB().pulse end, function(v) DB().pulse = v end,
        "Icons blink during their last 3 seconds.")
    check("Only my target", function() return DB().onlyTarget end, function(v) DB().onlyTarget = v end,
        "Only show icons on the nameplate of your current target.")
    check("Track friendly players", function() return DB().friendly end, function(v) DB().friendly = v end,
        "Also show timers on friendly player nameplates.")
    buttons({
        { "Test on target", 120, function()
            if not ns.TestPlates() then say("target a player with a visible nameplate first.") end
        end },
    })

    ---- Enemy offensive CC cooldowns ---------------------------------
    header("Enemy CC cooldowns (Blind, Scatter Shot...)")
    note("When an enemy uses a crowd-control ability, an icon with a countdown shows how long until they can use it again. Appears on their nameplate in a second row.")
    check("Track enemy CC cooldowns", function() return DB().ccd end, function(v) DB().ccd = v end)
    check("Only my target", function() return DB().ccdOnlyTarget end, function(v) DB().ccdOnlyTarget = v end,
        "Only show these on the nameplate of your current target.")
    stepper("Min cooldown to show (sec)", function() return DB().ccdMin end,
        function(v) DB().ccdMin = v end, 5, 0, 300)
    stepper("Icon size", function() return DB().ccdSize end, function(v) DB().ccdSize = v end, 4, 16, 128)
    stepper("Max icons per nameplate", function() return DB().ccdMax end, function(v) DB().ccdMax = v end, 1, 1, 8)
    stepper("Height from nameplate", function() return DB().ccdY end, function(v) DB().ccdY = v end, 2, -60, 200)
    note("Abilities to track (tick to include). 'Test on target' above also shows sample timers.")
    buttons({
        { "All on", 80, function() wipe(DB().ccdDisabled); changed(); refreshWidgets() end },
        { "All off", 80, function()
            for _, s in ipairs(ns.CC_CDS) do DB().ccdDisabled[s[1]] = true end
            changed(); refreshWidgets()
        end },
    })
    for _, s in ipairs(ns.CC_CDS) do
        local name, cd = s[1], s[2]
        local cdText = (cd >= 60) and (math.floor(cd / 60) .. "m") or (cd .. "s")
        check(name .. " (" .. cdText .. ")", function() return not DB().ccdDisabled[name] end,
            function(v) DB().ccdDisabled[name] = (not v) or nil end)
    end

    ---- Crowd control alert -----------------------------------------
    header("Crowd control alert (you are CC'd)")
    note("When you are stunned, feared, polymorphed, sapped, slept, rooted, silenced or disarmed, the spell icon and a countdown appear on screen until it fades.")
    check("Show CC alert", function() return DB().cc end, function(v) DB().cc = v end)
    check("Play sound when CC'd", function() return DB().ccSound end, function(v) DB().ccSound = v end)
    check("Show countdown number", function() return DB().ccText end, function(v) DB().ccText = v end)
    check("Show ability name", function() return DB().ccName end, function(v) DB().ccName = v end)
    stepper("CC icon size", function() return DB().ccSize end, function(v) DB().ccSize = v end, 8, 32, 256)
    stepper("Max CC icons shown", function() return DB().ccMax end, function(v) DB().ccMax = v end, 1, 1, 6)
    stepper("Horizontal position", function() return DB().ccX end, function(v) DB().ccX = v end, 10, -900, 900)
    stepper("Vertical position", function() return DB().ccY end, function(v) DB().ccY = v end, 10, -500, 500)
    local unlockBtn
    local function unlockText() unlockBtn:SetText(ns.CCIsUnlocked() and "Lock position" or "Move with mouse") end
    local row = buttons({
        { "Test CC alert", 110, function() ns.CCTest() end },
        { "Move with mouse", 130, function()
            ns.CCSetUnlocked(not ns.CCIsUnlocked()); unlockText()
        end },
        { "Reset position", 110, function() ns.CCResetPosition(); refreshWidgets() end },
    })
    unlockBtn = row[2]
    refreshers[#refreshers + 1] = unlockText
    unlockText()
    ns.OnCCMoved = refreshWidgets

    note("Which crowd control to show:")
    for _, cat in ipairs(ns.CC_ORDER) do
        local info = ns.CC_CATS[cat]
        check(info.label, function() return DB().ccCats[cat] end, function(v) DB().ccCats[cat] = v end)
    end

    ---- Tracked abilities -------------------------------------------
    header("Enemy abilities to track")
    buttons({
        { "All on", 80, function() wipe(DB().disabled); changed(); refreshWidgets() end },
        { "All off", 80, function()
            for _, s in ipairs(ns.SPELLS) do DB().disabled[s[1]] = true end
            changed(); refreshWidgets()
        end },
    })
    for _, s in ipairs(ns.SPELLS) do
        local name = s[1]
        check(name, function() return not DB().disabled[name] end,
            function(v) DB().disabled[name] = (not v) or nil end)
    end

    ---- Reset --------------------------------------------------------
    header("Reset")
    buttons({
        { "Reset all settings", 140, function()
            EDTDB = nil
            DB()
            if minimapBtn then minimapBtn:SetShown(true) end
            changed(); refreshWidgets()
            say("settings reset.")
        end },
    })

    endChecks()
    child:SetHeight(-y + 20)
    f:Hide()
    return f
end

local function toggleConfig(forceShow)
    if not cfg then cfg = build() end
    if forceShow or not cfg:IsShown() then
        refreshWidgets()
        cfg:Show()
    else
        cfg:Hide()
    end
end
ns.ToggleConfig = toggleConfig

--------------------------------------------------------------------------
-- minimap button
--------------------------------------------------------------------------
local atan2 = math.atan2 or math.atan

local function positionMinimap()
    if not minimapBtn or not Minimap then return end
    local a = math.rad(DB().minimapAngle or 200)
    local r = (Minimap:GetWidth() / 2) + 5
    minimapBtn:ClearAllPoints()
    minimapBtn:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
end

local function dragUpdate()
    local mx, my = Minimap:GetCenter()
    local px, py = GetCursorPosition()
    local s = Minimap:GetEffectiveScale()
    px, py = px / s, py / s
    DB().minimapAngle = math.deg(atan2(py - my, px - mx))
    positionMinimap()
end

local function createMinimapButton()
    if minimapBtn or not Minimap then return end
    local b = CreateFrame("Button", "EasyCDMinimapButton", Minimap)
    b:SetSize(32, 32)
    b:SetFrameStrata("MEDIUM")
    b:SetFrameLevel(8)
    b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
    b:RegisterForDrag("LeftButton")

    local overlay = b:CreateTexture(nil, "OVERLAY")
    overlay:SetSize(54, 54)
    overlay:SetTexture(136430)           -- MiniMap-TrackingBorder
    overlay:SetPoint("TOPLEFT")
    local bg = b:CreateTexture(nil, "BACKGROUND")
    bg:SetSize(20, 20)
    bg:SetTexture(136467)                -- UI-Minimap-Background
    bg:SetPoint("TOPLEFT", 7, -5)
    local icon = b:CreateTexture(nil, "ARTWORK")
    icon:SetSize(17, 17)
    icon:SetTexture("Interface\\Icons\\Spell_Frost_Frost")
    icon:SetTexCoord(0.07, 0.93, 0.07, 0.93)
    icon:SetPoint("TOPLEFT", 7, -6)
    b:SetHighlightTexture(136477)        -- UI-Minimap-ZoomButton-Highlight

    b:SetScript("OnDragStart", function(self) self:SetScript("OnUpdate", dragUpdate) end)
    b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
    b:SetScript("OnClick", function(_, button)
        if button == "RightButton" then
            DB().enabled = not DB().enabled
            say(DB().enabled and "on" or "off")
            changed()
            refreshWidgets()
        else
            toggleConfig()
        end
    end)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_LEFT")
        GameTooltip:AddLine("EasyCD")
        GameTooltip:AddLine("Left-click: settings", 1, 1, 1)
        GameTooltip:AddLine("Right-click: turn on/off", 1, 1, 1)
        GameTooltip:AddLine("Drag: move button", 1, 1, 1)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)

    minimapBtn = b
    positionMinimap()
    b:SetShown(not DB().hideMinimap)
end

-- entry in the game's AddOns options with a button that opens the window
local function registerOptionsPanel()
    local panel = CreateFrame("Frame")
    panel.name = "EasyCD"
    local t = panel:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    t:SetPoint("TOPLEFT", 16, -16)
    t:SetText("EasyCD")
    local b = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    b:SetSize(190, 24)
    b:SetPoint("TOPLEFT", 16, -48)
    b:SetText("Open EasyCD settings")
    b:SetScript("OnClick", function()
        toggleConfig(true)
        if SettingsPanel and HideUIPanel then pcall(HideUIPanel, SettingsPanel) end
    end)
    if Settings and Settings.RegisterCanvasLayoutCategory then
        local cat = Settings.RegisterCanvasLayoutCategory(panel, panel.name)
        Settings.RegisterAddOnCategory(cat)
    elseif InterfaceOptions_AddCategory then
        InterfaceOptions_AddCategory(panel)
    end
end

local boot = CreateFrame("Frame")
boot:RegisterEvent("PLAYER_LOGIN")
boot:SetScript("OnEvent", function()
    createMinimapButton()
    pcall(registerOptionsPanel)
end)

--------------------------------------------------------------------------
-- slash commands
--------------------------------------------------------------------------
SLASH_EDT1 = "/edt"
SLASH_EDT2 = "/easycd"
SlashCmdList["EDT"] = function(msg)
    local db = DB()
    local cmd, arg = (msg or ""):match("^(%S*)%s*(%S*)$")
    cmd = (cmd or ""):lower()
    local num = tonumber(arg)

    if cmd == "" or cmd == "config" or cmd == "options" or cmd == "settings" then
        toggleConfig()
        return
    elseif cmd == "test" then
        if not ns.TestPlates() then say("target a player with a visible nameplate first.") end
    elseif cmd == "cc" then
        ns.CCTest()
    elseif cmd == "unlock" then
        say(ns.CCSetUnlocked(not ns.CCIsUnlocked()) and "drag the CC icon, then /edt unlock again to lock it" or "CC icon locked")
    elseif cmd == "size" and num then
        db.size = math.max(16, math.min(128, num))
    elseif cmd == "max" and num then
        db.max = math.max(1, math.min(10, math.floor(num)))
    elseif cmd == "y" and num then
        db.y = num
    elseif cmd == "ccsize" and num then
        db.ccSize = math.max(32, math.min(256, num))
    elseif cmd == "friendly" then
        db.friendly = not db.friendly
        say("track friendly players: " .. tostring(db.friendly))
    elseif cmd == "minimap" then
        db.hideMinimap = not db.hideMinimap
        if minimapBtn then minimapBtn:SetShown(not db.hideMinimap) end
        say("minimap button " .. (db.hideMinimap and "hidden" or "shown"))
    elseif cmd == "reset" then
        EDTDB = nil
        DB()
        say("settings reset.")
    elseif cmd == "info" then
        say((IS_FOREVER and "Forever (aura scan)" or "Classic Era (combat log)") ..
            "  interface " .. tostring(select(4, GetBuildInfo())))
    else
        say("/edt (settings) | test | cc | unlock | size N | max N | y N | ccsize N | friendly | minimap | reset | info")
        return
    end
    changed()
    refreshWidgets()
end
