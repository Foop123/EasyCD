-- EasyCD crowd-control alert
-- When YOU are stunned, feared, polymorphed, sapped, slept, rooted, silenced or
-- disarmed, the spell's icon and a countdown appear on screen until it fades.
--
-- Sources: your own harmful auras matched against the list in Data.lua (Era and
-- Forever) plus, on Forever, the game's Loss of Control data so CC missing from
-- the list is still shown.
--
-- PERFORMANCE NOTES
--  * Only listens to UNIT_AURA for "player" (RegisterUnitEvent), and on Forever
--    ignores aura changes that cannot involve a crowd-control effect.
--  * Bursts of events are coalesced into one scan; scans reuse tables.
--  * The display is only re-laid-out when the list of CC changes; the 10 Hz ticker
--    only updates the countdown text and removes itself when nothing is shown.
--  * Everything is unregistered while the alert (or the addon) is disabled.
local ADDON_NAME, ns = ...
local DB, IS_FOREVER, issecret = ns.DB, ns.IS_FOREVER, ns.issecret
local GetSpellInfoCompat = ns.GetSpellInfoCompat
local CATS = ns.CC_CATS

local pairs, ipairs, wipe, sort = pairs, ipairs, wipe, table.sort
local floor, ceil, max, min = math.floor, math.ceil, math.max, math.min
local format, GetTime = string.format, GetTime
local HUGE = math.huge

local QMARK = "Interface\\Icons\\INV_Misc_QuestionMark"
local ccByName, ccById = {}, {}

local function BuildCCLookup()
    wipe(ccByName); wipe(ccById)
    for _, s in ipairs(ns.CC) do
        local entry = { name = s[1], cat = s[2] }
        for _, id in ipairs(s[3]) do
            local n, _, tex = GetSpellInfoCompat(id)
            if n then ccByName[n] = entry; entry.icon = entry.icon or tex end
            ccById[id] = entry
        end
        ccByName[s[1]] = ccByName[s[1]] or entry
        entry.icon = entry.icon or QMARK
    end
end

----------------------------------------------------------------------
-- State
----------------------------------------------------------------------
local ev = CreateFrame("Frame")
local holder, slots = nil, {}
local unlocked = false
local tests = {}
local current, nCur, shownN = {}, 0, 0      -- entries on screen (identity-stable between scans)
local buf, nBuf = {}, 0                      -- scan buffer (reused)
local seenKeys = {}
local prevKeys, nextKeys = {}, {}            -- for "new CC" detection (sound, source tracking)
local ccIds = {}                             -- auraInstanceIDs of the CC auras we found
local ccVer, layoutVer = 1, 0
local sampleEntry
local ticking, acc = false, 0

local function FormatTime(t)
    if t >= 60 then return format("%d:%02d", floor(t / 60), floor(t % 60)) end
    if t >= 10 then return format("%d", ceil(t)) end
    return format("%.1f", t)
end

local function Trim(t, n)
    for i = #t, n + 1, -1 do t[i] = nil end
end

local function SortDesc(a, b)
    return (a.exp or (a.static and -1 or HUGE)) > (b.exp or (b.static and -1 or HUGE))
end

----------------------------------------------------------------------
-- Display
----------------------------------------------------------------------
local function SavePosition()
    local x, y = holder:GetCenter()
    local ux, uy = UIParent:GetCenter()
    if not x or not ux then return end
    local db = DB()
    db.ccX = floor(x - ux + 0.5)
    db.ccY = floor(y - uy + 0.5)
    holder:ClearAllPoints()
    holder:SetPoint("CENTER", UIParent, "CENTER", db.ccX, db.ccY)
    if ns.OnCCMoved then ns.OnCCMoved() end
end

local function GetHolder()
    if holder then return holder end
    local h = CreateFrame("Frame", "EasyCDAlert", UIParent)
    h:SetSize(10, 10)
    h:SetFrameStrata("HIGH")
    h:SetMovable(true)
    h:SetClampedToScreen(true)
    h:Hide()

    h.handle = CreateFrame("Frame", nil, h)
    h.handle:SetAllPoints()
    h.handle:SetFrameLevel(h:GetFrameLevel() + 20)
    h.handle:EnableMouse(false)
    h.handle:RegisterForDrag("LeftButton")
    h.handle:SetScript("OnDragStart", function()
        if unlocked then h.moving = true; h:StartMoving() end
    end)
    h.handle:SetScript("OnDragStop", function()
        h:StopMovingOrSizing()
        h.moving = false
        SavePosition()
    end)
    holder = h
    return h
end

local function NewSlot(parent)
    local b = CreateFrame("Frame", nil, parent)
    b.edge = b:CreateTexture(nil, "BACKGROUND")
    b.edge:SetPoint("TOPLEFT", -3, 3)
    b.edge:SetPoint("BOTTOMRIGHT", 3, -3)
    b.edge:SetColorTexture(1, 1, 1, 1)
    b.tex = b:CreateTexture(nil, "ARTWORK")
    b.tex:SetAllPoints()
    b.tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)

    b.cd = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.cd:SetAllPoints()
    if b.cd.SetHideCountdownNumbers then b.cd:SetHideCountdownNumbers(true) end
    if b.cd.SetDrawEdge then b.cd:SetDrawEdge(false) end

    b.over = CreateFrame("Frame", nil, b)
    b.over:SetAllPoints()
    b.over:SetFrameLevel(b.cd:GetFrameLevel() + 2)
    b.time = b.over:CreateFontString(nil, "OVERLAY")
    b.time:SetFont(STANDARD_TEXT_FONT, 14, "OUTLINE")
    b.time:SetPoint("CENTER", 0, 0)
    b.label = b.over:CreateFontString(nil, "OVERLAY")
    b.label:SetFont(STANDARD_TEXT_FONT, 12, "OUTLINE")
    b.label:SetPoint("TOP", b, "BOTTOM", 0, -6)
    return b
end

-- countdown text only; returns true if something ran out
local function UpdateTexts(now)
    local showText = DB().ccText
    for i = 1, shownN do
        local e, s = current[i], slots[i]
        if e and s and e.exp then
            local remain = e.exp - now
            if remain <= 0 then return true end
            if showText then
                local key = (remain >= 10) and ceil(remain) or (floor(remain * 10) + 100000)
                if key ~= s.tkey then
                    s.tkey = key
                    s.time:SetText(FormatTime(remain))
                end
                local urgent = remain <= 3
                if urgent ~= s.urgent then
                    s.urgent = urgent
                    if urgent then s.time:SetTextColor(1, 0.35, 0.35) else s.time:SetTextColor(1, 1, 1) end
                end
            end
        end
    end
    return false
end

-- full layout: only when the list or a setting changed
local function Render()
    local db = DB()
    local h = GetHolder()
    shownN = min(nCur, db.ccMax)
    if shownN == 0 then
        h:Hide()
        for i = 1, #slots do slots[i]:Hide(); slots[i].shown, slots[i].cdEntry = nil, nil end
        return
    end

    local size, gap = db.ccSize, 12
    local total = shownN * size + (shownN - 1) * gap
    h:SetSize(total, size)
    if not h.moving then
        h:ClearAllPoints()
        h:SetPoint("CENTER", UIParent, "CENTER", db.ccX, db.ccY)
    end
    h.handle:EnableMouse(unlocked)
    h:Show()

    local fsz, lsz = max(14, floor(size * 0.42)), max(12, floor(size * 0.22))
    for i = 1, max(shownN, #slots) do
        local s = slots[i]
        if i <= shownN then
            local e = current[i]
            if not s then s = NewSlot(h); slots[i] = s end
            s:SetSize(size, size)
            s:ClearAllPoints()
            s:SetPoint("CENTER", h, "CENTER", -total / 2 + size / 2 + (i - 1) * (size + gap), 0)
            local c = CATS[e.cat] or CATS.incap
            s.edge:SetColorTexture(c.r, c.g, c.b, 1)
            s.tex:SetTexture(e.icon or QMARK)
            if s.fsz ~= fsz then s.time:SetFont(STANDARD_TEXT_FONT, fsz, "OUTLINE"); s.fsz = fsz end
            if s.lsz ~= lsz then s.label:SetFont(STANDARD_TEXT_FONT, lsz, "OUTLINE"); s.lsz = lsz end

            if s.cdEntry ~= e then
                s.cdEntry = e
                if e.durObj and s.cd.SetCooldownFromDurationObject then
                    s.cd:SetCooldownFromDurationObject(e.durObj)
                elseif e.start and e.dur then
                    s.cd:SetCooldown(e.start, e.dur)
                else
                    s.cd:Clear()
                end
            end
            s.shown = e
            s.tkey, s.urgent = nil, nil
            s.time:SetTextColor(1, 1, 1)
            s.label:SetTextColor(c.r, c.g, c.b)
            s.label:SetText(db.ccName and (e.name or "") or "")
            if not (db.ccText and e.exp) then s.time:SetText("") end
            s:Show()
        elseif s then
            s:Hide()
            s.shown, s.cdEntry = nil, nil
        end
    end
    UpdateTexts(GetTime())
end

local Refresh                                  -- forward

local function OnCCTick(_, elapsed)
    acc = acc + elapsed
    if acc < 0.1 then return end
    acc = 0
    if UpdateTexts(GetTime()) then Refresh() end      -- something ran out
end

local function SetTicking(on)
    if on and not ticking then
        ticking, acc = true, 0
        ev:SetScript("OnUpdate", OnCCTick)
    elseif not on and ticking then
        ticking = false
        ev:SetScript("OnUpdate", nil)
    end
end

----------------------------------------------------------------------
-- Finding the CC on the player
----------------------------------------------------------------------
local function push(e)
    local k = e.key
    if k then
        if seenKeys[k] then return end
        seenKeys[k] = true
    end
    if not DB().ccCats[e.cat] then return end
    nBuf = nBuf + 1
    buf[nBuf] = e
end

local GetAuraDataByIndex = C_UnitAuras and C_UnitAuras.GetAuraDataByIndex

local function DoScan()
    -- 1) harmful auras on you that match the CC list
    if GetAuraDataByIndex then
        for i = 1, 40 do
            local a = GetAuraDataByIndex("player", i, "HARMFUL")
            if not a then break end
            local sid, nm = a.spellId, a.name
            local info
            if sid and not issecret(sid) then info = ccById[sid] end
            if not info and nm and not issecret(nm) then info = ccByName[nm] end
            if info then
                local e = { cat = info.cat, icon = info.icon, name = info.name,
                            key = (sid and not issecret(sid)) and sid or info.name }
                if a.icon and not issecret(a.icon) then e.icon = a.icon end
                if nm and not issecret(nm) then e.name = nm end
                if a.sourceUnit and not issecret(a.sourceUnit) then e.sourceUnit = a.sourceUnit end
                local iid = a.auraInstanceID
                if iid and not issecret(iid) then ccIds[iid] = true end

                local dur, exp = a.duration, a.expirationTime
                if dur ~= nil and exp ~= nil and not issecret(dur) and not issecret(exp) then
                    if dur > 0 and exp > 0 then e.dur, e.exp, e.start = dur, exp, exp - dur end
                elseif C_UnitAuras.GetAuraDuration and iid then
                    e.durObj = C_UnitAuras.GetAuraDuration("player", iid)
                end
                if not e.exp and not e.durObj then e.static = true end
                push(e)
            end
        end
    elseif UnitDebuff then
        for i = 1, 40 do
            local nm, icon, _, _, dur, exp, _, _, _, sid = UnitDebuff("player", i)
            if not nm then break end
            local info = (sid and ccById[sid]) or ccByName[nm]
            if info then
                local e = { cat = info.cat, icon = icon or info.icon, name = nm, key = sid or nm }
                if dur and dur > 0 and exp and exp > 0 then
                    e.dur, e.exp, e.start = dur, exp, exp - dur
                else
                    e.static = true
                end
                push(e)
            end
        end
    end

    -- 2) Forever: the game's own Loss of Control data (catches CC not in the list)
    if C_LossOfControl and C_LossOfControl.GetActiveLossOfControlDataCount then
        local count = C_LossOfControl.GetActiveLossOfControlDataCount() or 0
        for i = 1, count do
            local d = C_LossOfControl.GetActiveLossOfControlData(i)
            if d and not issecret(d.locType) then
                local cat = ns.LOC_CAT[d.locType] or "incap"
                local shownType = d.displayType
                if issecret(shownType) or shownType == nil or shownType > 0 then
                    local sid = d.spellID
                    local name = d.displayText
                    if (not name or issecret(name)) and sid and not issecret(sid) then
                        name = GetSpellInfoCompat(sid)
                    end
                    local e = { cat = cat, name = name or "Crowd control",
                                key = (sid and not issecret(sid)) and sid or name,
                                icon = d.iconTexture or QMARK }
                    local dur, startT, left = d.duration, d.startTime, d.timeRemaining
                    if dur and startT and not issecret(dur) and not issecret(startT) and dur > 0 then
                        e.dur, e.start, e.exp = dur, startT, startT + dur
                    elseif left and not issecret(left) and left > 0 then
                        local now = GetTime()
                        e.dur, e.start, e.exp = left, now, now + left
                    else
                        e.static = true
                    end
                    push(e)
                end
            end
        end
    end
end

function Refresh()
    local db = DB()
    wipe(buf); nBuf = 0
    wipe(seenKeys); wipe(ccIds)

    local real = false
    if unlocked then
        sampleEntry = sampleEntry or { cat = "incap", name = "Drag me", static = true,
                                       icon = select(3, GetSpellInfoCompat(118)) or QMARK }
        nBuf = 1
        buf[1] = sampleEntry
    elseif db.enabled and db.cc then
        real = true
        pcall(DoScan)
        local now = GetTime()
        for i = #tests, 1, -1 do
            if tests[i].exp <= now then table.remove(tests, i) end
        end
        for i = 1, #tests do nBuf = nBuf + 1; buf[nBuf] = tests[i] end
    end

    -- newly applied CC: sound + tell the nameplate tracker who cast it (Forever)
    if real then
        wipe(nextKeys)
        local fresh = false
        for i = 1, nBuf do
            local e = buf[i]
            if e.key and not e.test then
                nextKeys[e.key] = true
                if not prevKeys[e.key] then
                    fresh = true
                    if e.sourceUnit and ns.NoteCCUse then pcall(ns.NoteCCUse, e.sourceUnit, e.key, e.name) end
                end
            end
        end
        prevKeys, nextKeys = nextKeys, prevKeys
        if fresh and db.ccSound then
            pcall(PlaySound, (SOUNDKIT and SOUNDKIT.RAID_WARNING) or 8959)
        end
    else
        wipe(prevKeys)
    end

    Trim(buf, nBuf)
    if nBuf > 1 then sort(buf, SortDesc) end

    -- reuse identical previous entries so an unchanged list costs nothing
    for i = 1, nBuf do
        local e = buf[i]
        if not e.durObj and not e.test and e ~= sampleEntry then
            for j = 1, nCur do
                local o = current[j]
                if o.key == e.key and o.exp == e.exp and o.cat == e.cat and not o.durObj then
                    buf[i] = o
                    break
                end
            end
        end
    end

    local same = (nBuf == nCur) and (layoutVer == ccVer)
    if same then
        for i = 1, nBuf do
            if current[i] ~= buf[i] then same = false; break end
        end
    end
    if same then return end

    for i = 1, nBuf do current[i] = buf[i] end
    Trim(current, nBuf)
    nCur, layoutVer = nBuf, ccVer
    Render()

    local need = false
    if not unlocked then
        for i = 1, nCur do
            if current[i].exp then need = true; break end
        end
    end
    SetTicking(need)
end

----------------------------------------------------------------------
-- Events
----------------------------------------------------------------------
local pending = false
local function Flush()
    pending = false
    Refresh()
end
local function MarkDirty()
    if not pending then
        pending = true
        C_Timer.After(0.03, Flush)
    end
end

-- Forever: can this UNIT_AURA payload involve a crowd-control effect?
local function CCAuraRelevant(info)
    if not info or info.isFullUpdate then return true end
    local added = info.addedAuras
    if added then
        for i = 1, #added do
            local a = added[i]
            if a.isHarmful ~= false then
                local sid, nm = a.spellId, a.name
                if sid and not issecret(sid) and ccById[sid] then return true end
                if nm and not issecret(nm) and ccByName[nm] then return true end
            end
        end
    end
    local r = info.removedAuraInstanceIDs
    if r then for i = 1, #r do if ccIds[r[i]] then return true end end end
    local u = info.updatedAuraInstanceIDs
    if u then for i = 1, #u do if ccIds[u[i]] then return true end end end
    return false
end

local LOC_EVENTS = { "LOSS_OF_CONTROL_ADDED", "LOSS_OF_CONTROL_UPDATE" }
local registered = false

local function UpdateRegistration()
    local db = DB()
    local want = (db.enabled and db.cc) and true or false
    if want == registered then return end
    registered = want
    if want then
        if ev.RegisterUnitEvent then ev:RegisterUnitEvent("UNIT_AURA", "player")
        else ev:RegisterEvent("UNIT_AURA") end
        ev:RegisterEvent("PLAYER_ENTERING_WORLD")
        if IS_FOREVER then
            for _, name in ipairs(LOC_EVENTS) do pcall(ev.RegisterEvent, ev, name) end
        end
    else
        ev:UnregisterAllEvents()
        ev:RegisterEvent("PLAYER_LOGIN")
    end
end

ev:RegisterEvent("PLAYER_LOGIN")
ev:SetScript("OnEvent", function(self, event, unit, info)
    if event == "UNIT_AURA" then
        if unit ~= "player" then return end
        if IS_FOREVER then
            local ok, rel = pcall(CCAuraRelevant, info)
            if ok and not rel then return end
        end
        MarkDirty()
    elseif event == "PLAYER_LOGIN" then
        BuildCCLookup()
        UpdateRegistration()
        Refresh()
    else
        MarkDirty()
    end
end)

----------------------------------------------------------------------
-- Public API (used by Config.lua)
----------------------------------------------------------------------
-- settings changed
function ns.CCRefresh()
    ccVer = ccVer + 1
    UpdateRegistration()
    Refresh()
end

function ns.CCTest()
    local now = GetTime()
    wipe(tests)
    for _, t in ipairs({
        { 118, "Polymorph", "incap", 8 },
        { 5782, "Fear", "fear", 6 },
        { 1833, "Cheap Shot", "stun", 4 },
    }) do
        local _, _, tex = GetSpellInfoCompat(t[1])
        tests[#tests + 1] = { cat = t[3], name = t[2], icon = tex or QMARK, test = true,
                              dur = t[4], start = now, exp = now + t[4], key = "test" .. t[1] }
    end
    Refresh()
end

function ns.CCSetUnlocked(v)
    unlocked = v and true or false
    ccVer = ccVer + 1
    GetHolder().handle:EnableMouse(unlocked)
    Refresh()
    return unlocked
end

function ns.CCIsUnlocked() return unlocked end

function ns.CCResetPosition()
    local db = DB()
    db.ccX, db.ccY = ns.DEFAULTS.ccX, ns.DEFAULTS.ccY
    ccVer = ccVer + 1
    Refresh()
end
