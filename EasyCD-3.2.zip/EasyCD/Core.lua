-- EasyCD core: enemy defensive icons + enemy offensive-CC cooldown icons on nameplates
--
-- Classic Era : reads the combat log (open to addons on Era).
-- Forever     : combat log is closed to addons, so it scans buffs on visible enemy
--               player nameplates (C_UnitAuras) and listens to spell-cast events.
--
-- PERFORMANCE NOTES
--  * Nothing runs per frame unless an icon is on screen; the 10 Hz ticker removes
--    itself when idle.
--  * Layout (sizes, anchors, fonts) is only redone when the list of icons or a
--    setting changes. The ticker only touches text that actually changed.
--  * NPC nameplates are ignored completely; only player plates are tracked.
--  * Forever: unit events are registered per nameplate (not for every raid/party
--    unit), UNIT_AURA is filtered with the update payload and coalesced to 10 Hz.
--  * Era: the combat-log handler rejects irrelevant events with two table lookups.
--  * Events are unregistered while the addon is disabled.
local ADDON_NAME, ns = ...
local DB, IS_FOREVER, issecret = ns.DB, ns.IS_FOREVER, ns.issecret
local GetSpellInfoCompat = ns.GetSpellInfoCompat

local pairs, ipairs, next, wipe, type = pairs, ipairs, next, wipe, type
local floor, ceil, max, min, abs = math.floor, math.ceil, math.max, math.min, math.abs
local format, sort = string.format, table.sort
local GetTime, UnitIsUnit, UnitGUID = GetTime, UnitIsUnit, UnitGUID
local HUGE = math.huge

local byName, byId = {}, {}
local ccdByName, ccdById = {}, {}
local QUESTION = "Interface\\Icons\\INV_Misc_QuestionMark"

local function BuildLookup()
    wipe(byName); wipe(byId); wipe(ccdByName); wipe(ccdById)
    for _, s in ipairs(ns.SPELLS) do
        local entry = { name = s[1], dur = s[2] }
        for _, id in ipairs(s[3]) do
            local n, _, tex = GetSpellInfoCompat(id)
            if n then byName[n] = entry; entry.icon = entry.icon or tex end
            byId[id] = entry
        end
        byName[s[1]] = byName[s[1]] or entry
        entry.icon = entry.icon or QUESTION
    end
    for _, s in ipairs(ns.CC_CDS) do
        local entry = { name = s[1], cd = s[2] }
        for _, id in ipairs(s[3]) do
            local n, _, tex = GetSpellInfoCompat(id)
            if n then ccdByName[n] = entry; entry.icon = entry.icon or tex end
            ccdById[id] = entry
        end
        ccdByName[s[1]] = ccdByName[s[1]] or entry
        entry.icon = entry.icon or QUESTION
    end
end

local frame = CreateFrame("Frame")

----------------------------------------------------------------------
-- Ticker (only exists while something is displayed)
----------------------------------------------------------------------
local settingsVer = 1
local tickRows, nTick, ticking = {}, 0, false
local RefreshPlate                       -- assigned further down

local function FormatTime(t)
    if t >= 60 then return format("%dm", ceil(t / 60)) end
    if t >= 10 then return format("%d", ceil(t)) end
    return format("%.1f", t)
end

local function FormatCD(t)
    if t >= 60 then return format("%d:%02d", floor(t / 60), floor(t % 60)) end
    return FormatTime(t)
end

-- updates only what changed: the number, its colour, the pulse
local function TickRow(d, now, noRefresh)
    local db = DB()
    local isCCD, showText, pulse = d.isCCD, db.showText, (not d.isCCD) and db.pulse
    local expired = false
    local icons = d.icons
    for i = 1, d.n do
        local icon = icons[i]
        local e = icon.shownEntry
        local remain = e and e.start and (e.start + e.dur - now)
        if remain then
            if remain <= 0 then
                expired = true
            else
                if showText then
                    local key = (remain >= 10) and ceil(remain) or (floor(remain * 10) + 100000)
                    if key ~= icon.tkey then
                        icon.tkey = key
                        icon.text:SetText(isCCD and FormatCD(remain) or FormatTime(remain))
                    end
                    if not isCCD then
                        local urgent = remain <= 5
                        if urgent ~= icon.urgent then
                            icon.urgent = urgent
                            if urgent then icon.text:SetTextColor(1, 0.3, 0.3) else icon.text:SetTextColor(1, 1, 0.2) end
                        end
                    end
                end
                if pulse and icon.pulse then
                    local p = remain <= 3
                    if p ~= icon.pulsing then
                        icon.pulsing = p
                        if p then icon.pulse:Play() else icon.pulse:Stop() end
                    end
                end
            end
        end
    end
    if expired and not noRefresh then RefreshPlate(d.plate) end
end

local acc = 0
local function OnTick(_, elapsed)
    acc = acc + elapsed
    if acc < 0.1 then return end
    acc = 0
    local now = GetTime()
    local i = 1
    while i <= nTick do
        local d = tickRows[i]
        if d.n == 0 then
            d.inTick = false
            tickRows[i] = tickRows[nTick]
            tickRows[nTick] = nil
            nTick = nTick - 1
        else
            TickRow(d, now)
            i = i + 1
        end
    end
    if nTick == 0 then
        frame:SetScript("OnUpdate", nil)
        ticking = false
    end
end

local function EnsureTick()
    if not ticking then
        ticking = true
        acc = 0
        frame:SetScript("OnUpdate", OnTick)
    end
end

----------------------------------------------------------------------
-- Icon widgets
----------------------------------------------------------------------
local function AttachPulse(icon)
    local ag = icon:CreateAnimationGroup()
    ag:SetLooping("BOUNCE")
    local a = ag:CreateAnimation("Alpha")
    if a.SetFromAlpha then a:SetFromAlpha(1); a:SetToAlpha(0.4) else a:SetChange(-0.6) end
    a:SetDuration(0.35)
    icon.pulse = ag
end

local function NewIcon(container, isCCD)
    local b = CreateFrame("Frame", nil, container)
    local bw = isCCD and 2 or 1
    b.bg = b:CreateTexture(nil, "BACKGROUND")
    if isCCD then b.bg:SetColorTexture(0.85, 0.12, 0.12, 1) else b.bg:SetColorTexture(0, 0, 0, 1) end
    b.bg:SetPoint("TOPLEFT", -bw, bw)
    b.bg:SetPoint("BOTTOMRIGHT", bw, -bw)
    b.tex = b:CreateTexture(nil, "ARTWORK")
    b.tex:SetAllPoints()
    b.tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    if isCCD then b.tex:SetVertexColor(0.7, 0.7, 0.7) end

    b.cd = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.cd:SetAllPoints()
    if b.cd.SetHideCountdownNumbers then b.cd:SetHideCountdownNumbers(true) end
    if b.cd.SetDrawEdge then b.cd:SetDrawEdge(false) end

    b.over = CreateFrame("Frame", nil, b)
    b.over:SetAllPoints()
    b.over:SetFrameLevel(b.cd:GetFrameLevel() + 2)
    b.text = b.over:CreateFontString(nil, "OVERLAY")
    b.text:SetFont(STANDARD_TEXT_FONT, 12, "OUTLINE")
    b.fontSize = 12
    b.text:SetPoint("CENTER", 0, 0)
    if isCCD then b.text:SetTextColor(1, 1, 1) end
    if not isCCD then AttachPulse(b) end
    return b
end

-- rows are created lazily: a plate with nothing to show never gets any frames
local function GetRow(plate, isCCD)
    plate.EDT = plate.EDT or { rows = {} }
    local key = isCCD and "ccd" or "def"
    local d = plate.EDT.rows[key]
    if not d then
        local c = CreateFrame("Frame", nil, plate)
        c:SetSize(1, 1)
        c:SetFrameLevel(plate:GetFrameLevel() + 10)
        d = { container = c, icons = {}, list = {}, n = 0, plate = plate, isCCD = isCCD }
        plate.EDT.rows[key] = d
    end
    return d
end

local function ClearPlate(plate)
    local e = plate and plate.EDT
    if not e then return end
    for _, d in pairs(e.rows) do
        d.n, d.ver = 0, nil
        for i = 1, #d.icons do
            local icon = d.icons[i]
            icon:Hide()
            icon.shownEntry, icon.cdEntry = nil, nil
            if icon.pulsing then icon.pulse:Stop(); icon.pulsing = false end
        end
        wipe(d.list)
    end
end

----------------------------------------------------------------------
-- Apply: filter + (only if something changed) lay the row out
-- entries : array of { icon, name, start, dur } or { icon, name, durObj }
----------------------------------------------------------------------
local vis = {}

local function Apply(plate, entries, unit, isCCD)
    local db = DB()
    local show = db.enabled and (not isCCD or db.ccd)
    if show and unit then
        local only = isCCD and db.ccdOnlyTarget or ((not isCCD) and db.onlyTarget)
        if only and not UnitIsUnit(unit, "target") then show = false end
    end

    local rows = plate.EDT and plate.EDT.rows
    local d = rows and rows[isCCD and "ccd" or "def"]

    local nv = 0
    if show then
        local disabled = isCCD and db.ccdDisabled or db.disabled
        local limit = isCCD and db.ccdMax or db.max
        local minCD = db.ccdMin
        for i = 1, #entries do
            local e = entries[i]
            if not (e.name and disabled[e.name]) and not (isCCD and e.dur < minCD) then
                nv = nv + 1
                vis[nv] = e
                if nv >= limit then break end
            end
        end
    end
    if nv == 0 and not d then return end
    d = d or GetRow(plate, isCCD)

    -- unchanged? then there is nothing to do
    if d.ver == settingsVer and d.n == nv then
        local list, same = d.list, true
        for i = 1, nv do
            if list[i] ~= vis[i] then same = false; break end
        end
        if same then return end
    end

    -- full layout -------------------------------------------------------
    local c = d.container
    local below = (db.anchor == "BELOW")
    local pt = below and "TOP" or "BOTTOM"
    local yOff = isCCD and db.ccdY or db.y
    c:ClearAllPoints()
    if below then c:SetPoint("TOP", plate, "BOTTOM", db.x, -yOff)
    else c:SetPoint("BOTTOM", plate, "TOP", db.x, yOff) end
    c:SetAlpha(db.alpha)

    local size, gap = (isCCD and db.ccdSize or db.size), db.gap
    local total = nv * size + max(0, nv - 1) * gap
    local startX = -total / 2
    if db.align == "LEFT" then startX = 0 elseif db.align == "RIGHT" then startX = -total end
    local fontSize = max(8, floor(size * 0.45 * db.textScale))
    local icons, list = d.icons, d.list

    for i = 1, max(nv, #icons) do
        local icon = icons[i]
        if i <= nv then
            local e = vis[i]
            if not icon then
                icon = NewIcon(c, isCCD)
                icons[i] = icon
            end
            icon:SetSize(size, size)
            icon:ClearAllPoints()
            icon:SetPoint(pt .. "LEFT", c, pt, startX + (i - 1) * (size + gap), 0)
            icon.tex:SetTexture(e.icon)
            icon.bg:SetShown(db.showBorder or isCCD)
            icon.cd:SetAlpha(db.showSwipe and 1 or 0)
            if icon.fontSize ~= fontSize then
                icon.text:SetFont(STANDARD_TEXT_FONT, fontSize, "OUTLINE")
                icon.fontSize = fontSize
            end
            if icon.cdEntry ~= e then
                icon.cdEntry = e
                if e.durObj and icon.cd.SetCooldownFromDurationObject then
                    icon.cd:SetCooldownFromDurationObject(e.durObj)
                elseif e.start then
                    icon.cd:SetCooldown(e.start, e.dur)
                end
            end
            icon.shownEntry = e
            icon.tkey, icon.urgent = nil, nil
            if icon.pulsing then icon.pulse:Stop(); icon.pulsing = false end
            if not db.showText then icon.text:SetText("") end
            icon:Show()
            list[i] = e
        elseif icon then
            icon:Hide()
            icon.shownEntry, icon.cdEntry = nil, nil
            if icon.pulsing then icon.pulse:Stop(); icon.pulsing = false end
        end
    end
    for i = #list, nv + 1, -1 do list[i] = nil end
    d.ver, d.n = settingsVer, nv

    if nv > 0 then
        if not d.inTick then
            d.inTick = true
            nTick = nTick + 1
            tickRows[nTick] = d
        end
        EnsureTick()
        TickRow(d, GetTime(), true)          -- first numbers right away
    end
end

----------------------------------------------------------------------
-- Shared state
----------------------------------------------------------------------
local forPlates, forEntries, forIds, forSeen, forTests, forSkip = {}, {}, {}, {}, {}, {}
local eraPlates, active = {}, {}      -- active[guid][spellName] = { icon, name, start, dur }
local ccdState = {}                   -- ccdState[key][spellName] = { icon, name, start, dur }
local entriesBuf = {}                 -- scratch (reused, never kept)

local function Trim(t, n)
    for i = #t, n + 1, -1 do t[i] = nil end
end

local function SortByEnd(a, b)
    return (a.start and (a.start + a.dur) or HUGE) < (b.start and (b.start + b.dur) or HUGE)
end

local function ccdKey(unit)
    local guid = UnitGUID(unit)
    if guid and not issecret(guid) then return guid end
    if unit:find("^nameplate") then return "unit:" .. unit end
    for u in pairs(forPlates) do
        if UnitIsUnit(u, unit) then return "unit:" .. u end
    end
end

function ns.StartCCD(key, info)
    if not key then return end
    local list = ccdState[key]
    if not list then list = {}; ccdState[key] = list end
    local now = GetTime()
    local old = list[info.name]
    if old and now < old.start + 2 then return end        -- same use seen twice (cast + aura / miss)
    list[info.name] = { icon = info.icon, name = info.name, start = now, dur = info.cd }
end

-- fills entriesBuf with the running CC cooldowns of this key; returns the count
local function CCDFill(key)
    local out, n = entriesBuf, 0
    local list = key and ccdState[key]
    if list then
        local now = GetTime()
        for name, e in pairs(list) do
            if now >= e.start + e.dur then list[name] = nil else n = n + 1; out[n] = e end
        end
        if not next(list) then ccdState[key] = nil end
    end
    Trim(out, n)
    if n > 1 then sort(out, SortByEnd) end
    return n
end

----------------------------------------------------------------------
-- FOREVER: scan buffs on enemy player nameplates
----------------------------------------------------------------------
local GetAuraDataByIndex = C_UnitAuras and C_UnitAuras.GetAuraDataByIndex

local function RefreshForever(unit)
    local plate = forPlates[unit]
    if not plate or plate.edtUnit ~= unit then return end
    local now = GetTime()
    local out, n = entriesBuf, 0
    local src = forEntries[unit]
    if src then
        for i = 1, #src do
            local e = src[i]
            if e.durObj or now < e.start + e.dur then n = n + 1; out[n] = e end
        end
    end
    local tests = forTests[unit]
    if tests then
        local alive = false
        for i = 1, #tests do
            local e = tests[i]
            if now < e.start + e.dur then n = n + 1; out[n] = e; alive = true end
        end
        if not alive then forTests[unit] = nil end
    end
    Trim(out, n)
    if n > 1 then sort(out, SortByEnd) end
    Apply(plate, out, unit, false)

    local k = CCDFill(ccdKey(unit))
    Apply(plate, entriesBuf, unit, true)
end

local function DoScanForever(unit)
    local prev = forEntries[unit]
    local list, ids
    local now = GetTime()
    local seenNow
    local db = DB()

    if UnitExists(unit) and UnitIsPlayer(unit) and (UnitIsEnemy("player", unit) or db.friendly) then
        for i = 1, 40 do
            local a = GetAuraDataByIndex(unit, i, "HELPFUL")
            if not a then break end

            local info
            local sid, nm = a.spellId, a.name
            if sid and not issecret(sid) then info = byId[sid] end
            if not info and nm and not issecret(nm) then info = byName[nm] end

            if info then
                local e = { icon = info.icon, name = info.name }
                local dur, exp = a.duration, a.expirationTime
                if dur ~= nil and exp ~= nil and not issecret(dur) and not issecret(exp) then
                    if dur > 0 and exp > 0 then e.start, e.dur = exp - dur, dur end
                elseif GetAuraDataByIndex and C_UnitAuras.GetAuraDuration and a.auraInstanceID then
                    e.durObj = C_UnitAuras.GetAuraDuration(unit, a.auraInstanceID)
                end
                if not e.start and not e.durObj and (dur == nil or dur == 0) then
                    -- client gives no timing for enemy auras: time it from first sighting
                    forSeen[unit] = forSeen[unit] or {}
                    seenNow = seenNow or {}
                    seenNow[info.name] = true
                    forSeen[unit][info.name] = forSeen[unit][info.name] or now
                    e.start, e.dur = forSeen[unit][info.name], info.dur
                end
                if e.start or e.durObj then
                    -- keep the identical previous entry so Apply sees "no change"
                    if prev and e.start then
                        for j = 1, #prev do
                            local p = prev[j]
                            if p.name == e.name and p.start and abs(p.start - e.start) < 0.05 and p.dur == e.dur then
                                e = p
                                break
                            end
                        end
                    end
                    list = list or {}
                    list[#list + 1] = e
                    local iid = a.auraInstanceID
                    if iid and not issecret(iid) then
                        ids = ids or {}
                        ids[iid] = true
                    end
                end
            end
        end
    end

    forEntries[unit] = list
    forIds[unit] = ids
    local seen = forSeen[unit]
    if seen then
        for key in pairs(seen) do
            if not (seenNow and seenNow[key]) then seen[key] = nil end
        end
        if not next(seen) then forSeen[unit] = nil end
    end
end

local function ScanForever(unit)
    pcall(DoScanForever, unit)
    RefreshForever(unit)
end

-- UNIT_AURA payload filter: is anything that changed one of our tracked buffs?
local function AuraTracked(a)
    local sid, nm = a.spellId, a.name
    if sid and not issecret(sid) and byId[sid] then return true end
    if nm and not issecret(nm) and byName[nm] then return true end
    return false
end

local function UnitAuraRelevant(unit, info)
    if not info or info.isFullUpdate then return true end
    local added = info.addedAuras
    if added then
        for i = 1, #added do
            local a = added[i]
            if a.isHelpful ~= false and AuraTracked(a) then return true end
        end
    end
    local ids = forIds[unit]
    if ids then
        local r = info.removedAuraInstanceIDs
        if r then for i = 1, #r do if ids[r[i]] then return true end end end
        local u = info.updatedAuraInstanceIDs
        if u then for i = 1, #u do if ids[u[i]] then return true end end end
    end
    return false
end

-- coalesce bursts of aura changes into one scan per unit per 0.1 s
local forDirty, flushPending = {}, false
local function FlushDirty()
    flushPending = false
    for unit in pairs(forDirty) do
        forDirty[unit] = nil
        if forPlates[unit] and not forSkip[unit] then ScanForever(unit) end
    end
end

local function OnPlateAura(unit, info)
    if not forPlates[unit] or forSkip[unit] then return end       -- NPC / friendly plates: ignore
    local ok, rel = pcall(UnitAuraRelevant, unit, info)
    if ok and not rel then return end
    forDirty[unit] = true
    if not flushPending then
        flushPending = true
        C_Timer.After(0.1, FlushDirty)
    end
end

----------------------------------------------------------------------
-- ERA: combat log
----------------------------------------------------------------------
local function ScanDurationEra(unit, auraName)
    if not unit or not UnitBuff then return end
    for i = 1, 40 do
        local name, _, _, _, duration, expiration = UnitBuff(unit, i)
        if not name then break end
        if name == auraName and duration and duration > 0 and expiration and expiration > 0 then
            return duration, expiration
        end
    end
end

local function RefreshEra(guid)
    local plate = eraPlates[guid]
    if not plate then return end
    if plate.edtGuid ~= guid then eraPlates[guid] = nil; return end   -- plate was recycled
    local unit = plate.namePlateUnitToken
    local out, n = entriesBuf, 0
    local list = active[guid]
    if list then
        local now = GetTime()
        for key, e in pairs(list) do
            if now >= e.start + e.dur then list[key] = nil else n = n + 1; out[n] = e end
        end
        if not next(list) then active[guid] = nil end
    end
    Trim(out, n)
    if n > 1 then sort(out, SortByEnd) end
    Apply(plate, out, unit, false)

    CCDFill(guid)
    Apply(plate, entriesBuf, unit, true)
end

local band = bit.band
local function IsTrackedFlags(flags)
    if band(flags, COMBATLOG_OBJECT_TYPE_PLAYER or 0x400) == 0 then return false end
    if band(flags, COMBATLOG_OBJECT_REACTION_HOSTILE or 0x40) ~= 0 then return true end
    return DB().friendly
end

local EV_AURA = { SPELL_AURA_APPLIED = true, SPELL_AURA_REFRESH = true, SPELL_AURA_REMOVED = true }
local EV_CC   = { SPELL_CAST_SUCCESS = true, SPELL_MISSED = true, SPELL_AURA_APPLIED = true }

local function OnCombatLog()
    local _, sub, _, srcGUID, _, srcFlags, _, destGUID, _, destFlags, _, spellId, spellName, _, auraType =
        CombatLogGetCurrentEventInfo()
    local isAura, isCC = EV_AURA[sub], EV_CC[sub]
    if not isAura and not isCC then return end                     -- most events end here

    local dinfo = isAura and (byId[spellId] or byName[spellName])
    local cinfo = isCC and (ccdById[spellId] or ccdByName[spellName])
    if not dinfo and not cinfo then return end                      -- ...and most of the rest here

    -- enemy used an offensive CC ability -> start its cooldown timer
    if cinfo and srcGUID and IsTrackedFlags(srcFlags) then
        ns.StartCCD(srcGUID, cinfo)
        if eraPlates[srcGUID] then RefreshEra(srcGUID) end
    end

    -- defensive buff gained / lost
    if dinfo and destGUID and auraType == "BUFF" and IsTrackedFlags(destFlags) then
        if sub == "SPELL_AURA_REMOVED" then
            local list = active[destGUID]
            if list then
                list[spellName] = nil
                if not next(list) then active[destGUID] = nil end
            end
        else
            local list = active[destGUID]
            if not list then list = {}; active[destGUID] = list end
            list[spellName] = { icon = dinfo.icon, name = dinfo.name, start = GetTime(), dur = dinfo.dur }
            C_Timer.After(0.1, function()
                local plate = eraPlates[destGUID]
                local e = active[destGUID] and active[destGUID][spellName]
                if plate and e then
                    local dur, exp = ScanDurationEra(plate.namePlateUnitToken, spellName)
                    if dur then e.dur, e.start = dur, exp - dur; RefreshEra(destGUID) end
                end
            end)
        end
        if eraPlates[destGUID] then RefreshEra(destGUID) end
    end
end

----------------------------------------------------------------------
-- Generic helpers
----------------------------------------------------------------------
function RefreshPlate(plate)
    if plate.edtUnit then RefreshForever(plate.edtUnit)
    elseif plate.edtGuid then RefreshEra(plate.edtGuid) end
end

local function RefreshPlates()               -- re-filter / re-layout, no rescanning
    if IS_FOREVER then
        for unit in pairs(forPlates) do RefreshForever(unit) end
    else
        for guid in pairs(eraPlates) do RefreshEra(guid) end
    end
end

-- Forever: detect offensive CC use (no combat log available)
local function RefreshPlateOf(unit)
    for u in pairs(forPlates) do
        if UnitIsUnit(u, unit) then RefreshForever(u) end
    end
end

local function HandleCast(unit, spellID)
    if not spellID or issecret(spellID) then return end
    local info = ccdById[spellID]
    if not info then return end                                    -- almost every cast ends here
    if type(unit) ~= "string" or issecret(unit) then return end
    if not UnitIsPlayer(unit) then return end
    if not (UnitIsEnemy("player", unit) or DB().friendly) then return end
    ns.StartCCD(ccdKey(unit), info)
    RefreshPlateOf(unit)
end

-- called by CC.lua when a CC lands on you and the game tells us who cast it
function ns.NoteCCUse(unit, spellId, spellName)
    if not IS_FOREVER or type(unit) ~= "string" or issecret(unit) then return end
    local info = (spellId and not issecret(spellId) and ccdById[spellId])
              or (spellName and not issecret(spellName) and ccdByName[spellName])
    if not info then return end
    if not UnitExists(unit) or not UnitIsPlayer(unit) or not UnitIsEnemy("player", unit) then return end
    ns.StartCCD(ccdKey(unit), info)
    RefreshPlateOf(unit)
end

----------------------------------------------------------------------
-- Event registration (nothing is registered while the addon is disabled)
----------------------------------------------------------------------
local unitFrames = {}
local regState

local function OnUnitEvent(_, event, unit, a2, a3)
    if event == "UNIT_AURA" then
        OnPlateAura(unit, a2)
    else
        pcall(HandleCast, unit, a3)
    end
end

local function BuildUnitFrames()
    if #unitFrames > 0 then return end
    local units = { "target", "focus" }
    for i = 1, 40 do units[#units + 1] = "nameplate" .. i end
    for _, u in ipairs(units) do
        local f = CreateFrame("Frame")
        f.unit = u
        f.isPlate = u:find("^nameplate") and true or false
        f:SetScript("OnEvent", OnUnitEvent)
        unitFrames[#unitFrames + 1] = f
    end
end

local function UpdateRegistration()
    local want = DB().enabled and true or false
    if want == regState then return end
    regState = want
    if IS_FOREVER then
        for _, f in ipairs(unitFrames) do
            if want then
                if f.isPlate then f:RegisterUnitEvent("UNIT_AURA", f.unit) end
                pcall(f.RegisterUnitEvent, f, "UNIT_SPELLCAST_SUCCEEDED", f.unit)
            else
                f:UnregisterAllEvents()
            end
        end
    else
        if want then frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
        else frame:UnregisterEvent("COMBAT_LOG_EVENT_UNFILTERED") end
    end
end

----------------------------------------------------------------------
-- Public API
----------------------------------------------------------------------
-- settings changed: re-evaluate everything
function ns.RefreshAll()
    settingsVer = settingsVer + 1
    UpdateRegistration()
    local db = DB()
    if IS_FOREVER then
        for unit, plate in pairs(forPlates) do
            forSkip[unit] = not (UnitIsEnemy("player", unit) or db.friendly)
            if forSkip[unit] then forEntries[unit], forIds[unit] = nil, nil end
            ScanForever(unit)
        end
    else
        for guid in pairs(eraPlates) do RefreshEra(guid) end
    end
end

-- shows fake icons on the nameplate of your current target; returns false if there is none
function ns.TestPlates()
    local names = { "Ice Block", "Shield Wall", "Free Action", "Power Word: Shield", "Divine Shield" }
    local ccNames = { "Blind", "Scatter Shot", "Wyvern Sting", "Counterspell" }
    local now = GetTime()
    if IS_FOREVER then
        for unit in pairs(forPlates) do
            if UnitIsUnit(unit, "target") then
                local tests = {}
                for _, n in ipairs(names) do
                    local info = byName[n]
                    if info then tests[#tests + 1] = { icon = info.icon, name = info.name, start = now, dur = info.dur } end
                end
                forTests[unit] = tests
                local key = ccdKey(unit)
                for _, n in ipairs(ccNames) do
                    if ccdByName[n] then ns.StartCCD(key, ccdByName[n]) end
                end
                RefreshForever(unit)
                return true
            end
        end
    else
        local guid = UnitGUID("target")
        if guid and eraPlates[guid] then
            active[guid] = active[guid] or {}
            for _, n in ipairs(names) do
                local info = byName[n]
                if info then active[guid][n] = { icon = info.icon, name = info.name, start = now, dur = info.dur } end
            end
            for _, n in ipairs(ccNames) do
                if ccdByName[n] then ns.StartCCD(guid, ccdByName[n]) end
            end
            RefreshEra(guid)
            return true
        end
    end
    return false
end

----------------------------------------------------------------------
-- Main events
----------------------------------------------------------------------
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:RegisterEvent("PLAYER_TARGET_CHANGED")
frame:RegisterEvent("NAME_PLATE_UNIT_ADDED")
frame:RegisterEvent("NAME_PLATE_UNIT_REMOVED")

frame:SetScript("OnEvent", function(self, event, arg1)
    if event == "COMBAT_LOG_EVENT_UNFILTERED" then
        OnCombatLog()

    elseif event == "NAME_PLATE_UNIT_ADDED" then
        local plate = C_NamePlate.GetNamePlateForUnit(arg1)
        if not plate then return end
        if plate.EDT then ClearPlate(plate) end            -- plate frames are recycled
        plate.edtUnit, plate.edtGuid = nil, nil
        if not DB().enabled or not UnitIsPlayer(arg1) then return end   -- NPCs cost nothing
        if IS_FOREVER then
            plate.edtUnit = arg1
            forPlates[arg1] = plate
            forSkip[arg1] = not (UnitIsEnemy("player", arg1) or DB().friendly)
            if not forSkip[arg1] then ScanForever(arg1) end
        else
            local guid = UnitGUID(arg1)
            if guid then
                plate.namePlateUnitToken = arg1
                plate.edtGuid = guid
                eraPlates[guid] = plate
                RefreshEra(guid)
            end
        end

    elseif event == "NAME_PLATE_UNIT_REMOVED" then
        if IS_FOREVER then
            local plate = forPlates[arg1]
            if plate then
                ClearPlate(plate)
                plate.edtUnit = nil
            end
            forPlates[arg1], forEntries[arg1], forIds[arg1] = nil, nil, nil
            forSeen[arg1], forTests[arg1], forSkip[arg1], forDirty[arg1] = nil, nil, nil, nil
            ccdState["unit:" .. arg1] = nil
        else
            local plate = C_NamePlate.GetNamePlateForUnit(arg1)
            if plate then
                if plate.edtGuid then eraPlates[plate.edtGuid] = nil end
                plate.edtGuid = nil
                ClearPlate(plate)
            end
        end

    elseif event == "PLAYER_TARGET_CHANGED" then
        local db = DB()
        if db.onlyTarget or db.ccdOnlyTarget then RefreshPlates() end

    elseif event == "ADDON_LOADED" then
        if arg1 == ADDON_NAME then
            DB()
            self:UnregisterEvent("ADDON_LOADED")
        end

    elseif event == "PLAYER_LOGIN" then
        BuildLookup()
        if IS_FOREVER then BuildUnitFrames() end
        UpdateRegistration()
        self:UnregisterEvent("PLAYER_LOGIN")
    end
end)
